# Dash Sidebar App Template: PDPrognosis

Created on 2024-03-18 00:57:33.561622

Welcome to your [Plotly Dash](https://plotly.com/dash/) App! This is a template for your PDPrognosis app.

See [Faculty.ai](https://dash-bootstrap-components.opensource.faculty.ai/examples/) for more information.

## Running the App

Run `src/app.py` and navigate to http://127.0.0.1:8050/ in your browser.

